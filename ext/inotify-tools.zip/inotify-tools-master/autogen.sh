#!/bin/sh

autoreconf --install "$@" || exit 1
